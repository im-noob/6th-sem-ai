# Tic Tac Toe with Basic AI
🤖 Tic Tac Toe game written in java, with Artificial intelligence

## Contributing
Feel free to fork it and contribute with this code by optimizing it
